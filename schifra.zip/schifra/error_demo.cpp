#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

#include "schifra_galois_field.hpp"
#include "schifra_reed_solomon_encoder.hpp"
#include "schifra_reed_solomon_decoder.hpp"
#include "schifra_reed_solomon_block.hpp"
#include "schifra_error_processes.hpp"

// Function to print data in hex format
void print_hex(const std::string& label, const schifra::reed_solomon::erasure_locations_t& data, std::size_t length) {
    std::cout << label << " [";
    for (std::size_t i = 0; i < length; ++i) {
        std::cout << " " << std::hex << std::setw(2) << std::setfill('0') << (int)data[i];
    }
    std::cout << " ]" << std::dec << std::endl;
}

int main() {
    // Setup the finite field and codec
    const std::size_t field_descriptor = 8;
    const std::size_t generator_polynomial_index = 120;
    const std::size_t generator_polynomial_root_count = 16; // Can correct up to 8 errors
    
    // Create the Galois Field
    schifra::galois::field field(field_descriptor,
                                schifra::galois::primitive_polynomial_size06,
                                schifra::galois::primitive_polynomial06);

    // Create the codec
    schifra::reed_solomon::encoder<255, 223> encoder(field, generator_polynomial_index);
    schifra::reed_solomon::decoder<255, 223> decoder(field, generator_polynomial_index);

    // Our original message (28 characters)
    std::string message = "Hello, this is a test message!";
    
    // Make sure the message fits in codec's capacity
    if (message.length() > 223) {
        std::cout << "Message is too long!" << std::endl;
        return 1;
    }

    // Create code blocks
    schifra::reed_solomon::block<255> original_block;
    schifra::reed_solomon::block<255> encoded_block;
    schifra::reed_solomon::block<255> corrupted_block;
    schifra::reed_solomon::block<255> decoded_block;

    // Copy message to original block
    std::memcpy(original_block.data(), message.c_str(), message.length());
    
    // Encode the message
    if (!encoder.encode(original_block, encoded_block)) {
        std::cout << "Encoding failed!" << std::endl;
        return 1;
    }

    // Make a copy to corrupt
    corrupted_block = encoded_block;

    // Introduce 5 random errors (positions unknown to the decoder)
    const int num_errors = 5;
    for (int i = 0; i < num_errors; ++i) {
        // Generate a random position and value to corrupt
        std::size_t pos = rand() % 255;  // Random position
        schifra::galois::field_symbol value = rand() % 256;  // Random value
        
        std::cout << "Adding error at position: " << pos 
                  << " (changing " << (int)corrupted_block[pos] 
                  << " to " << (int)value << ")" << std::endl;
        
        corrupted_block[pos] = value;  // Corrupt the data
    }

    // Decode the corrupted message
    if (!decoder.decode(corrupted_block, decoded_block)) {
        std::cout << "Decoding failed! Too many errors to correct." << std::endl;
        return 1;
    }

    // Print results
    std::cout << "\nOriginal message: " << message << std::endl;
    std::cout << "Original as hex: ";
    print_hex("", original_block.data(), message.length());
    
    std::cout << "\nCorrupted data (first 50 bytes):" << std::endl;
    print_hex("  ", corrupted_block.data(), std::min(50, 255));
    
    std::cout << "\nDecoded message: " << std::string(decoded_block.data(), decoded_block.data() + message.length()) << std::endl;
    std::cout << "Decoded as hex: ";
    print_hex("", decoded_block.data(), message.length());

    // Verify the correction
    if (std::memcmp(original_block.data(), decoded_block.data(), message.length()) == 0) {
        std::cout << "\nSuccess! All errors were corrected." << std::endl;
    } else {
        std::cout << "\nCorrection failed! The decoded message doesn't match the original." << std::endl;
    }

    return 0;
}
