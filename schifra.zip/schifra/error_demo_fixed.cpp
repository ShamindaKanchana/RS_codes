#include <iostream>
#include <string>

#include "schifra_galois_field.hpp"
#include "schifra_reed_solomon_encoder.hpp"
#include "schifra_reed_solomon_decoder.hpp"

int main() {
    // Use a predefined codec from the library
    const std::size_t code_length = 255;
    const std::size_t fec_length = 32;  // Can correct up to 16 errors
    const std::size_t data_length = code_length - fec_length;

    // Create the Galois Field
    const schifra::galois::field field(8,
                                     schifra::galois::primitive_polynomial_size06,
                                     schifra::galois::primitive_polynomial06);

    // Create encoder and decoder with a specific generator polynomial index
    const std::size_t generator_polynomial_index = 120;
    schifra::reed_solomon::encoder<code_length, fec_length> encoder(field, generator_polynomial_index);
    schifra::reed_solomon::decoder<code_length, fec_length> decoder(field, generator_polynomial_index);

    // Our message (must be <= data_length characters)
    std::string message = "Hello, this is a test message for Reed-Solomon demo!";
    message.resize(data_length, ' ');  // Pad with spaces if needed

    std::cout << "Original Message: [" << message << "]" << std::endl;

    // Encode the message
    schifra::reed_solomon::block<code_length, fec_length> block;
    if (!encoder.encode(message, block)) {
        std::cout << "Encoding failed!" << std::endl;
        return 1;
    }

    // Make a copy to corrupt
    schifra::reed_solomon::block<code_length, fec_length> corrupted_block = block;

    // Introduce some errors (positions unknown to the decoder)
    const int num_errors = 10;  // Less than fec_length/2 to ensure correction is possible
    std::cout << "\nAdding " << num_errors << " random errors at unknown positions" << std::endl;
    
    for (int i = 0; i < num_errors; ++i) {
        std::size_t pos = rand() % code_length;
        corrupted_block[pos] = rand() % 256;  // Random corruption
    }

    // Decode the corrupted message
    if (!decoder.decode(corrupted_block)) {
        std::cout << "Decoding failed! Too many errors to correct." << std::endl;
        return 1;
    }

    // Get the decoded message
    std::string decoded_message;
    if (!corrupted_block.data_to_string(decoded_message)) {
        std::cout << "Failed to convert decoded data to string!" << std::endl;
        return 1;
    }
    decoded_message.resize(message.length());  // Trim to original message length

    std::cout << "\nDecoded Message: [" << decoded_message << "]" << std::endl;

    // Verify the correction
    if (message == decoded_message) {
        std::cout << "\nSuccess! All errors were corrected." << std::endl;
    } else {
        std::cout << "\nCorrection failed! The decoded message doesn't match the original." << std::endl;
    }

    return 0;
}
