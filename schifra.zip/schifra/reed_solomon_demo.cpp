#include <iostream>
#include <string>

#include "schifra_galois_field.hpp"
#include "schifra_galois_field_polynomial.hpp"
#include "schifra_sequential_root_generator_polynomial_creator.hpp"
#include "schifra_reed_solomon_encoder.hpp"
#include "schifra_reed_solomon_decoder.hpp"
#include "schifra_reed_solomon_block.hpp"

int main() {
    // 1. Set up the finite field parameters
    const std::size_t field_descriptor = 8;
    const std::size_t generator_polynomial_index = 120;
    const std::size_t generator_polynomial_root_count = 32;  // Can correct up to 16 errors
    
    // 2. Set up the Reed-Solomon code parameters
    const std::size_t code_length = 255;
    const std::size_t fec_length = 32;   // 32 parity symbols
    const std::size_t data_length = code_length - fec_length;  // 223 data symbols

    // 3. Create the Galois Field
    const schifra::galois::field field(field_descriptor,
                                     schifra::galois::primitive_polynomial_size06,
                                     schifra::galois::primitive_polynomial06);

    // 4. Create the generator polynomial
    schifra::galois::field_polynomial generator_polynomial(field);
    
    if (!schifra::make_sequential_root_generator_polynomial(
            field,
            generator_polynomial_index,
            generator_polynomial_root_count,
            generator_polynomial)) {
        std::cout << "Error: Failed to create generator polynomial!" << std::endl;
        return 1;
    }

    // 5. Define the codec types
    typedef schifra::reed_solomon::encoder<code_length, fec_length, data_length> encoder_t;
    typedef schifra::reed_solomon::decoder<code_length, fec_length, data_length> decoder_t;

    // 6. Create encoder and decoder instances
    const encoder_t encoder(field, generator_polynomial);
    const decoder_t decoder(field, generator_polynomial_index);

    // 7. Create a message to encode (must be <= data_length characters)
    std::string message = "This is a test message for Reed-Solomon error correction demo!";
    message.resize(data_length, ' ');  // Pad with spaces if needed

    std::cout << "Original Message: [" << message << "]\n\n";

    // 8. Create a block to hold the encoded data
    schifra::reed_solomon::block<code_length, fec_length, data_length> block;
    
    // 9. Encode the message
    if (!encoder.encode(message, block)) {
        std::cout << "Encoding failed!" << std::endl;
        return 1;
    }

    // 10. Make a copy to corrupt
    schifra::reed_solomon::block<code_length, fec_length, data_length> corrupted_block = block;

    // 11. Introduce some random errors (positions unknown to the decoder)
    const int num_errors = 10;  // Less than fec_length/2 to ensure correction is possible
    std::cout << "Adding " << num_errors << " random errors at unknown positions...\n";
    
    for (int i = 0; i < num_errors; ++i) {
        std::size_t pos = rand() % code_length;
        // Store original value for demonstration
        unsigned char original = corrupted_block[pos];
        // Corrupt the data
        corrupted_block[pos] = (original + 1 + (rand() % 254)) % 256;
        std::cout << "  - Position " << pos << ": " << (int)original 
                  << " -> " << (int)corrupted_block[pos] << std::endl;
    }

    // 12. Decode the corrupted message
    if (!decoder.decode(corrupted_block)) {
        std::cout << "\nDecoding failed! Too many errors to correct." << std::endl;
        return 1;
    }

    // 13. Get the decoded message
    std::string decoded_message(message.length(), '\0');
    for (std::size_t i = 0; i < message.length(); ++i) {
        decoded_message[i] = corrupted_block[i];
    }

    // 14. Display results
    std::cout << "\nDecoded Message: [" << decoded_message << "]\n";

    // 15. Verify the correction
    if (message == decoded_message) {
        std::cout << "\nSuccess! All errors were corrected.\n";
    } else {
        std::cout << "\nCorrection failed! The decoded message doesn't match the original.\n";
    }

    return 0;
}
