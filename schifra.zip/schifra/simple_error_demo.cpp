#include <iostream>
#include <string>
#include <cstring>

#include "schifra_galois_field.hpp"
#include "schifra_reed_solomon_encoder.hpp"
#include "schifra_reed_solomon_decoder.hpp"
#include "schifra_reed_solomon_block.hpp"


#include <ctime>  // Add this include for std::time
#include <cstdlib>  // Add this for std::srand and std::rand

int main() {
    // Setup the finite field and codec
    const std::size_t field_descriptor = 8;
    const std::size_t generator_polynomial_index = 120;
    const std::size_t generator_polynomial_root_count = 32; // 2t = 32 for (255,223) code
    
    // Create the Galois Field
    schifra::galois::field field(field_descriptor,
                               schifra::galois::primitive_polynomial_size06,
                               schifra::galois::primitive_polynomial06);

    // Create the generator polynomial
    schifra::galois::field_polynomial generator_polynomial(field);
    schifra::reed_solomon::compute_generator_polynomial(field, generator_polynomial_index, 
                                                      generator_polynomial_root_count, 
                                                      generator_polynomial);

    // Create the codec (255, 223) code - can correct up to 16 symbol errors
    schifra::reed_solomon::encoder<255, 223> encoder(field, generator_polynomial);
    schifra::reed_solomon::decoder<255, 223> decoder(field, generator_polynomial_root_count);

    // Our original message (must be <= 223 bytes)
    const char* message = "Hello, this is a test message for error correction demo!";
    const std::size_t message_length = std::strlen(message);

    // Create code blocks
    schifra::reed_solomon::block<255, 223, 32> original_block;
    schifra::reed_solomon::block<255, 223, 32> encoded_block;
    schifra::reed_solomon::block<255, 223, 32> corrupted_block;
    schifra::reed_solomon::block<255, 223, 32> decoded_block;

    // Copy message to original block
    std::memcpy(&original_block[0], message, message_length);
    
    std::cout << "Original message: " << message << "\n";
    
    // Encode the message
    if (!encoder.encode(original_block)) {
        std::cout << "Encoding failed!\n";
        return 1;
    }

    // Make a copy to corrupt
    corrupted_block = original_block;

    // Seed the random number generator
    std::srand(static_cast<unsigned int>(std::time(0)));

    // Introduce 5 random errors (positions unknown to the decoder)
    const int num_errors = 5;
    std::cout << "\nAdding " << num_errors << " random errors at unknown positions:\n";
    
    for (int i = 0; i < num_errors; ++i) {
        // Generate a random position and value to corrupt
        std::size_t pos = std::rand() % 255;  // Random position
        schifra::galois::field_symbol value = std::rand() % 256;  // Random value
        
        std::cout << "  - Position " << pos 
                  << ": Changing " << (int)corrupted_block[pos] 
                  << " to " << (int)value << "\n";
        
        corrupted_block[pos] = value;  // Corrupt the data
    }

    // Decode the corrupted message
    decoded_block = corrupted_block;
    if (!decoder.decode(decoded_block)) {
        std::cout << "\nDecoding failed! Too many errors to correct.\n";
        return 1;
    }

    // Print results
    std::cout << "\nDecoded message: ";
    for (std::size_t i = 0; i < message_length; ++i) {
        std::cout << decoded_block[i];
    }
    std::cout << "\n";

    // Verify the correction
    bool success = true;
    for (std::size_t i = 0; i < message_length; ++i) {
        if (original_block[i] != decoded_block[i]) {
            success = false;
            break;
        }
    }

    if (success) {
        std::cout << "\nSuccess! All errors were corrected.\n";
    } else {
        std::cout << "\nCorrection failed! The decoded message doesn't match the original.\n";
    }

    return 0;
}